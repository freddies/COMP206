#!/bin/bash

umask 077

if [[ ! -f logparser.bash ]]
then
	echo "Error there is no logparser.bash in the current directory"
	exit 1
fi

if [[ ! -x logparser.bash ]]
then
	chmod u+x logparser.bash
fi

rm -f logdata.csv stats.csv stats.html


echo ""
echo "[[ Usage test cases ]]"
echo ""
echo "--no arguments-- "
echo ./logparser.bash
./logparser.bash
rc=$?
echo ""
echo "program terminated with code = $rc"
echo ""

echo ""
echo "-- argument is not a dir--"
echo ./logparser.bash  /bin/ls
./logparser.bash  /bin/ls
rc=$?
echo ""
echo "program terminated with code = $rc"
echo ""


rm -f logdata.csv stats.csv stats.html


echo ""
echo "[[ Valid scenario test case ]]"
echo ""
echo ./logparser.bash  /home/2013/jdsilv2/206/mini3/TALogSet
./logparser.bash  /home/2013/jdsilv2/206/mini3/TALogSet
rc=$?
echo ""
echo "program terminated with code = $rc"
echo ""

for f in logdata.csv stats.csv stats.html
do
	if [[ ! -f $f ]]
	then
		echo "Error! unable to locate $f"
	fi
done

if [[ -f stats.csv ]]
then
	echo ""
	echo ""
	echo "stats CSV contents"
	echo ""
	cat stats.csv
	echo ""
else
	echo "Error! unable to locate stats.csv"
fi

if [[ ! -f stats.html ]]
then
	echo "Error! unable to locate stats.html"
else
	echo ""
	echo ""
	echo "HTML contents"
	echo ""
	cat stats.html
	echo ""
	echo "Would you like to see HTML contents using lynx?(y/n)" > /dev/tty
	read resp
	if [[ $resp =~ [yY] ]]
	then
		exec 1> /dev/tty
		lynx stats.html
	fi
fi
